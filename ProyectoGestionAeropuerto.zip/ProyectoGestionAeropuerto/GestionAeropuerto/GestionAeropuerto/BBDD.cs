﻿using System;
using System.Data;

namespace GestionAeropuerto
{


    partial class BBDD
    {
    }
}

namespace GestionAeropuerto.BBDDTableAdapters {


    public partial class AvionTableAdapter
    {
        internal DataTable IdAvion(string text)
        {
            throw new NotImplementedException();
        }
    }
}
