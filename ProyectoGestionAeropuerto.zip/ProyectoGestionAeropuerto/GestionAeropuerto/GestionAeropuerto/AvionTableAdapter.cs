﻿using System;
using System.Data;

namespace GestionAeropuerto
{
    internal class AvionTableAdapter
    {
        internal DataTable PaisOrigen(string text)
        {
            throw new NotImplementedException();
        }
    }
}