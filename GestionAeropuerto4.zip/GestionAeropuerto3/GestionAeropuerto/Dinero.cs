﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GestionAeropuerto
{
    public partial class Dinero : Form
    {
        public Dinero()
        {
            InitializeComponent();
        }

        private void empleadoBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.empleadoBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.bBDD);

        }

        private void Dinero_Load(object sender, EventArgs e)
        {
            // TODO: esta línea de código carga datos en la tabla 'bBDD.Nomina' Puede moverla o quitarla según sea necesario.
            this.nominaTableAdapter.Fill(this.bBDD.Nomina);
            

        }

        private void button1_Click(object sender, EventArgs e)
        {
            DataTable tabla4 = new DataTable();
            BBDDTableAdapters.EmpleadoTableAdapter aviones2 = new BBDDTableAdapters.EmpleadoTableAdapter();
            tabla4 = aviones2.Dinero(textBox1.Text);
            empleadoDataGridView.DataSource = tabla4;

            DataTable tabla5 = new DataTable();
            BBDDTableAdapters.NominaTableAdapter dinero = new BBDDTableAdapters.NominaTableAdapter();
            tabla5 = dinero.Dinero(textBox1.Text);
            nominaDataGridView.DataSource = tabla5;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
            Empleados ven = new Empleados();
            ven.Show();
        }
    }
}
