﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GestionAeropuerto
{
    public partial class Pasajero : Form
    {
        public Pasajero()
        {
            InitializeComponent();
        }

        /*private void pasajeroBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.pasajeroBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.bBDD);

        }

        private void Pasajero_Load(object sender, EventArgs e)
        {
            // TODO: esta línea de código carga datos en la tabla 'bBDD.Pasajero' Puede moverla o quitarla según sea necesario.
            this.pasajeroTableAdapter.Fill(this.bBDD.Pasajero);

        }

        private void pasajeroDataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void pasajeroDataGridView_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {

        }*/

        private void button1_Click(object sender, EventArgs e)
        {
            Nombre ventana = new Nombre();
            ventana.Show();
            this.Visible = false;
        }

        private void button3_Click(object sender, EventArgs e)
        {
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            NumAvion2 ventana = new NumAvion2();
            ventana.Show();
            this.Visible = false;
        }

        private void button3_Click_1(object sender, EventArgs e)
        {

            DNIEmpleado ventana = new DNIEmpleado();
            ventana.Show();
            this.Visible = false;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
            Form1 ven = new Form1();
            ven.Show();
        }

        private void pasajeroBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {

        }
    }
}
