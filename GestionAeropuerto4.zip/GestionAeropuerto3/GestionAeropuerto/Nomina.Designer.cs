﻿namespace GestionAeropuerto
{
    partial class Nomina
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label idNominaLabel;
            System.Windows.Forms.Label dNIEmpleadoLabel;
            System.Windows.Forms.Label fechaLabel;
            System.Windows.Forms.Label horaLabel;
            System.Windows.Forms.Label brutoLabel;
            System.Windows.Forms.Label netoLabel;
            System.Windows.Forms.Label iRPFLabel;
            System.Windows.Forms.Label sSLabel;
            System.Windows.Forms.Label dietasLabel;
            System.Windows.Forms.Label trieniosLabel;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Nomina));
            this.bBDD = new GestionAeropuerto.BBDD();
            this.nominaBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.nominaTableAdapter = new GestionAeropuerto.BBDDTableAdapters.NominaTableAdapter();
            this.tableAdapterManager = new GestionAeropuerto.BBDDTableAdapters.TableAdapterManager();
            this.nominaBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.nominaBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.nominaDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.idNominaTextBox = new System.Windows.Forms.TextBox();
            this.dNIEmpleadoTextBox = new System.Windows.Forms.TextBox();
            this.fechaDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.horaTextBox = new System.Windows.Forms.TextBox();
            this.brutoTextBox = new System.Windows.Forms.TextBox();
            this.netoTextBox = new System.Windows.Forms.TextBox();
            this.iRPFTextBox = new System.Windows.Forms.TextBox();
            this.sSTextBox = new System.Windows.Forms.TextBox();
            this.dietasTextBox = new System.Windows.Forms.TextBox();
            this.trieniosTextBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.button4 = new System.Windows.Forms.Button();
            idNominaLabel = new System.Windows.Forms.Label();
            dNIEmpleadoLabel = new System.Windows.Forms.Label();
            fechaLabel = new System.Windows.Forms.Label();
            horaLabel = new System.Windows.Forms.Label();
            brutoLabel = new System.Windows.Forms.Label();
            netoLabel = new System.Windows.Forms.Label();
            iRPFLabel = new System.Windows.Forms.Label();
            sSLabel = new System.Windows.Forms.Label();
            dietasLabel = new System.Windows.Forms.Label();
            trieniosLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.bBDD)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nominaBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nominaBindingNavigator)).BeginInit();
            this.nominaBindingNavigator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nominaDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // idNominaLabel
            // 
            idNominaLabel.AutoSize = true;
            idNominaLabel.Location = new System.Drawing.Point(328, 96);
            idNominaLabel.Name = "idNominaLabel";
            idNominaLabel.Size = new System.Drawing.Size(58, 13);
            idNominaLabel.TabIndex = 2;
            idNominaLabel.Text = "Id Nomina:";
            // 
            // dNIEmpleadoLabel
            // 
            dNIEmpleadoLabel.AutoSize = true;
            dNIEmpleadoLabel.Location = new System.Drawing.Point(328, 122);
            dNIEmpleadoLabel.Name = "dNIEmpleadoLabel";
            dNIEmpleadoLabel.Size = new System.Drawing.Size(76, 13);
            dNIEmpleadoLabel.TabIndex = 4;
            dNIEmpleadoLabel.Text = "DNIEmpleado:";
            dNIEmpleadoLabel.Click += new System.EventHandler(this.dNIEmpleadoLabel_Click);
            // 
            // fechaLabel
            // 
            fechaLabel.AutoSize = true;
            fechaLabel.Location = new System.Drawing.Point(328, 149);
            fechaLabel.Name = "fechaLabel";
            fechaLabel.Size = new System.Drawing.Size(40, 13);
            fechaLabel.TabIndex = 6;
            fechaLabel.Text = "Fecha:";
            // 
            // horaLabel
            // 
            horaLabel.AutoSize = true;
            horaLabel.Location = new System.Drawing.Point(328, 174);
            horaLabel.Name = "horaLabel";
            horaLabel.Size = new System.Drawing.Size(33, 13);
            horaLabel.TabIndex = 8;
            horaLabel.Text = "Hora:";
            // 
            // brutoLabel
            // 
            brutoLabel.AutoSize = true;
            brutoLabel.Location = new System.Drawing.Point(328, 200);
            brutoLabel.Name = "brutoLabel";
            brutoLabel.Size = new System.Drawing.Size(35, 13);
            brutoLabel.TabIndex = 10;
            brutoLabel.Text = "Bruto:";
            // 
            // netoLabel
            // 
            netoLabel.AutoSize = true;
            netoLabel.Location = new System.Drawing.Point(328, 226);
            netoLabel.Name = "netoLabel";
            netoLabel.Size = new System.Drawing.Size(33, 13);
            netoLabel.TabIndex = 12;
            netoLabel.Text = "Neto:";
            // 
            // iRPFLabel
            // 
            iRPFLabel.AutoSize = true;
            iRPFLabel.Location = new System.Drawing.Point(328, 252);
            iRPFLabel.Name = "iRPFLabel";
            iRPFLabel.Size = new System.Drawing.Size(34, 13);
            iRPFLabel.TabIndex = 14;
            iRPFLabel.Text = "IRPF:";
            // 
            // sSLabel
            // 
            sSLabel.AutoSize = true;
            sSLabel.Location = new System.Drawing.Point(328, 278);
            sSLabel.Name = "sSLabel";
            sSLabel.Size = new System.Drawing.Size(24, 13);
            sSLabel.TabIndex = 16;
            sSLabel.Text = "SS:";
            // 
            // dietasLabel
            // 
            dietasLabel.AutoSize = true;
            dietasLabel.Location = new System.Drawing.Point(328, 304);
            dietasLabel.Name = "dietasLabel";
            dietasLabel.Size = new System.Drawing.Size(40, 13);
            dietasLabel.TabIndex = 18;
            dietasLabel.Text = "Dietas:";
            // 
            // trieniosLabel
            // 
            trieniosLabel.AutoSize = true;
            trieniosLabel.Location = new System.Drawing.Point(328, 330);
            trieniosLabel.Name = "trieniosLabel";
            trieniosLabel.Size = new System.Drawing.Size(47, 13);
            trieniosLabel.TabIndex = 20;
            trieniosLabel.Text = "Trienios:";
            // 
            // bBDD
            // 
            this.bBDD.DataSetName = "BBDD";
            this.bBDD.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // nominaBindingSource
            // 
            this.nominaBindingSource.DataMember = "Nomina";
            this.nominaBindingSource.DataSource = this.bBDD;
            // 
            // nominaTableAdapter
            // 
            this.nominaTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.AvionTableAdapter = null;
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.ControlTecnicoTableAdapter = null;
            this.tableAdapterManager.EmpleadoTableAdapter = null;
            this.tableAdapterManager.NominaTableAdapter = this.nominaTableAdapter;
            this.tableAdapterManager.PasajeroTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = GestionAeropuerto.BBDDTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager.VueloTableAdapter = null;
            // 
            // nominaBindingNavigator
            // 
            this.nominaBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.nominaBindingNavigator.BindingSource = this.nominaBindingSource;
            this.nominaBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.nominaBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.nominaBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.nominaBindingNavigatorSaveItem});
            this.nominaBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.nominaBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.nominaBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.nominaBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.nominaBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.nominaBindingNavigator.Name = "nominaBindingNavigator";
            this.nominaBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.nominaBindingNavigator.Size = new System.Drawing.Size(1059, 25);
            this.nominaBindingNavigator.TabIndex = 0;
            this.nominaBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorAddNewItem.Text = "Agregar nuevo";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(35, 22);
            this.bindingNavigatorCountItem.Text = "of {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Número total de elementos";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorDeleteItem.Text = "Eliminar";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Mover primero";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Mover anterior";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Posición";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Posición actual";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem.Text = "Mover siguiente";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem.Text = "Mover último";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // nominaBindingNavigatorSaveItem
            // 
            this.nominaBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.nominaBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("nominaBindingNavigatorSaveItem.Image")));
            this.nominaBindingNavigatorSaveItem.Name = "nominaBindingNavigatorSaveItem";
            this.nominaBindingNavigatorSaveItem.Size = new System.Drawing.Size(23, 22);
            this.nominaBindingNavigatorSaveItem.Text = "Guardar datos";
            this.nominaBindingNavigatorSaveItem.Click += new System.EventHandler(this.nominaBindingNavigatorSaveItem_Click);
            // 
            // nominaDataGridView
            // 
            this.nominaDataGridView.AutoGenerateColumns = false;
            this.nominaDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.nominaDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn8,
            this.dataGridViewTextBoxColumn9,
            this.dataGridViewTextBoxColumn10});
            this.nominaDataGridView.DataSource = this.nominaBindingSource;
            this.nominaDataGridView.Location = new System.Drawing.Point(0, 378);
            this.nominaDataGridView.Name = "nominaDataGridView";
            this.nominaDataGridView.Size = new System.Drawing.Size(1039, 205);
            this.nominaDataGridView.TabIndex = 1;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "IdNomina";
            this.dataGridViewTextBoxColumn1.HeaderText = "IdNomina";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "DNIEmpleado";
            this.dataGridViewTextBoxColumn2.HeaderText = "DNIEmpleado";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "Fecha";
            this.dataGridViewTextBoxColumn3.HeaderText = "Fecha";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "Hora";
            this.dataGridViewTextBoxColumn4.HeaderText = "Hora";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "Bruto";
            this.dataGridViewTextBoxColumn5.HeaderText = "Bruto";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "Neto";
            this.dataGridViewTextBoxColumn6.HeaderText = "Neto";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "IRPF";
            this.dataGridViewTextBoxColumn7.HeaderText = "IRPF";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.DataPropertyName = "SS";
            this.dataGridViewTextBoxColumn8.HeaderText = "SS";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.DataPropertyName = "Dietas";
            this.dataGridViewTextBoxColumn9.HeaderText = "Dietas";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            // 
            // dataGridViewTextBoxColumn10
            // 
            this.dataGridViewTextBoxColumn10.DataPropertyName = "Trienios";
            this.dataGridViewTextBoxColumn10.HeaderText = "Trienios";
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            // 
            // idNominaTextBox
            // 
            this.idNominaTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.nominaBindingSource, "IdNomina", true));
            this.idNominaTextBox.Location = new System.Drawing.Point(410, 93);
            this.idNominaTextBox.Name = "idNominaTextBox";
            this.idNominaTextBox.Size = new System.Drawing.Size(200, 20);
            this.idNominaTextBox.TabIndex = 3;
            // 
            // dNIEmpleadoTextBox
            // 
            this.dNIEmpleadoTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.nominaBindingSource, "DNIEmpleado", true));
            this.dNIEmpleadoTextBox.Location = new System.Drawing.Point(410, 119);
            this.dNIEmpleadoTextBox.Name = "dNIEmpleadoTextBox";
            this.dNIEmpleadoTextBox.Size = new System.Drawing.Size(200, 20);
            this.dNIEmpleadoTextBox.TabIndex = 5;
            // 
            // fechaDateTimePicker
            // 
            this.fechaDateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.nominaBindingSource, "Fecha", true));
            this.fechaDateTimePicker.Location = new System.Drawing.Point(410, 145);
            this.fechaDateTimePicker.Name = "fechaDateTimePicker";
            this.fechaDateTimePicker.Size = new System.Drawing.Size(200, 20);
            this.fechaDateTimePicker.TabIndex = 7;
            // 
            // horaTextBox
            // 
            this.horaTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.nominaBindingSource, "Hora", true));
            this.horaTextBox.Location = new System.Drawing.Point(410, 171);
            this.horaTextBox.Name = "horaTextBox";
            this.horaTextBox.Size = new System.Drawing.Size(200, 20);
            this.horaTextBox.TabIndex = 9;
            // 
            // brutoTextBox
            // 
            this.brutoTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.nominaBindingSource, "Bruto", true));
            this.brutoTextBox.Location = new System.Drawing.Point(410, 197);
            this.brutoTextBox.Name = "brutoTextBox";
            this.brutoTextBox.Size = new System.Drawing.Size(200, 20);
            this.brutoTextBox.TabIndex = 11;
            // 
            // netoTextBox
            // 
            this.netoTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.nominaBindingSource, "Neto", true));
            this.netoTextBox.Location = new System.Drawing.Point(410, 223);
            this.netoTextBox.Name = "netoTextBox";
            this.netoTextBox.Size = new System.Drawing.Size(200, 20);
            this.netoTextBox.TabIndex = 13;
            // 
            // iRPFTextBox
            // 
            this.iRPFTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.nominaBindingSource, "IRPF", true));
            this.iRPFTextBox.Location = new System.Drawing.Point(410, 249);
            this.iRPFTextBox.Name = "iRPFTextBox";
            this.iRPFTextBox.Size = new System.Drawing.Size(200, 20);
            this.iRPFTextBox.TabIndex = 15;
            // 
            // sSTextBox
            // 
            this.sSTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.nominaBindingSource, "SS", true));
            this.sSTextBox.Location = new System.Drawing.Point(410, 275);
            this.sSTextBox.Name = "sSTextBox";
            this.sSTextBox.Size = new System.Drawing.Size(200, 20);
            this.sSTextBox.TabIndex = 17;
            // 
            // dietasTextBox
            // 
            this.dietasTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.nominaBindingSource, "Dietas", true));
            this.dietasTextBox.Location = new System.Drawing.Point(410, 301);
            this.dietasTextBox.Name = "dietasTextBox";
            this.dietasTextBox.Size = new System.Drawing.Size(200, 20);
            this.dietasTextBox.TabIndex = 19;
            // 
            // trieniosTextBox
            // 
            this.trieniosTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.nominaBindingSource, "Trienios", true));
            this.trieniosTextBox.Location = new System.Drawing.Point(410, 327);
            this.trieniosTextBox.Name = "trieniosTextBox";
            this.trieniosTextBox.Size = new System.Drawing.Size(200, 20);
            this.trieniosTextBox.TabIndex = 21;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(405, 40);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(109, 25);
            this.label1.TabIndex = 22;
            this.label1.Text = "NOMINAS";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(794, 301);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(197, 41);
            this.button4.TabIndex = 23;
            this.button4.Text = "VOLVER ATRAS";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // Nomina
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1059, 585);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.label1);
            this.Controls.Add(idNominaLabel);
            this.Controls.Add(this.idNominaTextBox);
            this.Controls.Add(dNIEmpleadoLabel);
            this.Controls.Add(this.dNIEmpleadoTextBox);
            this.Controls.Add(fechaLabel);
            this.Controls.Add(this.fechaDateTimePicker);
            this.Controls.Add(horaLabel);
            this.Controls.Add(this.horaTextBox);
            this.Controls.Add(brutoLabel);
            this.Controls.Add(this.brutoTextBox);
            this.Controls.Add(netoLabel);
            this.Controls.Add(this.netoTextBox);
            this.Controls.Add(iRPFLabel);
            this.Controls.Add(this.iRPFTextBox);
            this.Controls.Add(sSLabel);
            this.Controls.Add(this.sSTextBox);
            this.Controls.Add(dietasLabel);
            this.Controls.Add(this.dietasTextBox);
            this.Controls.Add(trieniosLabel);
            this.Controls.Add(this.trieniosTextBox);
            this.Controls.Add(this.nominaDataGridView);
            this.Controls.Add(this.nominaBindingNavigator);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Nomina";
            this.Text = "Nomina";
            this.Load += new System.EventHandler(this.Nomina_Load);
            ((System.ComponentModel.ISupportInitialize)(this.bBDD)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nominaBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nominaBindingNavigator)).EndInit();
            this.nominaBindingNavigator.ResumeLayout(false);
            this.nominaBindingNavigator.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nominaDataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private BBDD bBDD;
        private System.Windows.Forms.BindingSource nominaBindingSource;
        private BBDDTableAdapters.NominaTableAdapter nominaTableAdapter;
        private BBDDTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator nominaBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton nominaBindingNavigatorSaveItem;
        private System.Windows.Forms.DataGridView nominaDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.TextBox idNominaTextBox;
        private System.Windows.Forms.TextBox dNIEmpleadoTextBox;
        private System.Windows.Forms.DateTimePicker fechaDateTimePicker;
        private System.Windows.Forms.TextBox horaTextBox;
        private System.Windows.Forms.TextBox brutoTextBox;
        private System.Windows.Forms.TextBox netoTextBox;
        private System.Windows.Forms.TextBox iRPFTextBox;
        private System.Windows.Forms.TextBox sSTextBox;
        private System.Windows.Forms.TextBox dietasTextBox;
        private System.Windows.Forms.TextBox trieniosTextBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button4;
    }
}