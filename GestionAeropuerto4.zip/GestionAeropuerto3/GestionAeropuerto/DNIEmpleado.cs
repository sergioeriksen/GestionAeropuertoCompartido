﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GestionAeropuerto
{
    public partial class DNIEmpleado : Form
    {
        public DNIEmpleado()
        {
            InitializeComponent();
        }

        private void pasajeroBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.pasajeroBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.bBDD);

        }

        private void DNIEmpleado_Load(object sender, EventArgs e)
        {
            // TODO: esta línea de código carga datos en la tabla 'bBDD.Pasajero' Puede moverla o quitarla según sea necesario.
           // this.pasajeroTableAdapter.Fill(this.bBDD.Pasajero);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            DataTable tabla4 = new DataTable();
            //BBDDTableAdapters.PasajeroTableAdapter aviones2 = new BBDDTableAdapters.PasajeroTableAdapter();
          //  tabla4 = aviones2.DNIEmpleado(textBox1.Text);
            pasajeroDataGridView.DataSource = tabla4;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
            Pasajero ven = new Pasajero();
            ven.Show();
        }
    }
}
