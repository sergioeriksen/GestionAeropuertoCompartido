﻿using System;
using System.Data;

namespace GestionAeropuerto
{


    partial class BBDD
    {
        partial class EmpleadoDataTable
        {
        }

        partial class PasajeroDataTable
        {
        }
    }
}

namespace GestionAeropuerto.BBDDTableAdapters
{
    partial class EmpleadoTableAdapter
    {
    }

    partial class VueloTableAdapter
    {
        internal void Fill(BBDD.AvionDataTable avion)
        {
            throw new NotImplementedException();
        }
    }

    public partial class AvionTableAdapter
    {
        internal DataTable IdAvion(string text)
        {
            throw new NotImplementedException();
        }
    }
}
