﻿namespace GestionAeropuerto
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.avionBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.bBDD = new GestionAeropuerto.BBDD();
            this.avionTableAdapter = new GestionAeropuerto.BBDDTableAdapters.AvionTableAdapter();
            this.tableAdapterManager = new GestionAeropuerto.BBDDTableAdapters.TableAdapterManager();
            this.bindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.aVIONESToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.vUELOSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.aVIONToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pASAJEROToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.eMPLEADOSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.vUELOToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.nOMINAToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.avionBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bBDD)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).BeginInit();
            this.contextMenuStrip1.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // avionBindingSource
            // 
            this.avionBindingSource.DataMember = "Avion";
            this.avionBindingSource.DataSource = this.bBDD;
            // 
            // bBDD
            // 
            this.bBDD.DataSetName = "BBDD";
            this.bBDD.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // avionTableAdapter
            // 
            this.avionTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.AvionTableAdapter = this.avionTableAdapter;
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.ControlTecnicoTableAdapter = null;
            this.tableAdapterManager.EmpleadoTableAdapter = null;
            this.tableAdapterManager.NominaTableAdapter = null;
            this.tableAdapterManager.PasajeroTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = GestionAeropuerto.BBDDTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager.VueloTableAdapter = null;
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aVIONESToolStripMenuItem,
            this.vUELOSToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(123, 48);
            // 
            // aVIONESToolStripMenuItem
            // 
            this.aVIONESToolStripMenuItem.Name = "aVIONESToolStripMenuItem";
            this.aVIONESToolStripMenuItem.Size = new System.Drawing.Size(122, 22);
            this.aVIONESToolStripMenuItem.Text = "AVIONES";
            // 
            // vUELOSToolStripMenuItem
            // 
            this.vUELOSToolStripMenuItem.Name = "vUELOSToolStripMenuItem";
            this.vUELOSToolStripMenuItem.Size = new System.Drawing.Size(122, 22);
            this.vUELOSToolStripMenuItem.Text = "VUELOS";
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aVIONToolStripMenuItem,
            this.eMPLEADOSToolStripMenuItem,
            this.vUELOToolStripMenuItem,
            this.nOMINAToolStripMenuItem,
            this.pASAJEROToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1018, 24);
            this.menuStrip1.TabIndex = 5;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // aVIONToolStripMenuItem
            // 
            this.aVIONToolStripMenuItem.Name = "aVIONToolStripMenuItem";
            this.aVIONToolStripMenuItem.Size = new System.Drawing.Size(55, 20);
            this.aVIONToolStripMenuItem.Text = "AVION";
            this.aVIONToolStripMenuItem.Click += new System.EventHandler(this.aVIONToolStripMenuItem_Click);
            // 
            // pASAJEROToolStripMenuItem
            // 
            this.pASAJEROToolStripMenuItem.Name = "pASAJEROToolStripMenuItem";
            this.pASAJEROToolStripMenuItem.Size = new System.Drawing.Size(74, 20);
            this.pASAJEROToolStripMenuItem.Text = "PASAJERO";
            this.pASAJEROToolStripMenuItem.Click += new System.EventHandler(this.pASAJEROToolStripMenuItem_Click);
            // 
            // eMPLEADOSToolStripMenuItem
            // 
            this.eMPLEADOSToolStripMenuItem.Name = "eMPLEADOSToolStripMenuItem";
            this.eMPLEADOSToolStripMenuItem.Size = new System.Drawing.Size(86, 20);
            this.eMPLEADOSToolStripMenuItem.Text = "EMPLEADOS";
            this.eMPLEADOSToolStripMenuItem.Click += new System.EventHandler(this.eMPLEADOSToolStripMenuItem_Click);
            // 
            // vUELOToolStripMenuItem
            // 
            this.vUELOToolStripMenuItem.Name = "vUELOToolStripMenuItem";
            this.vUELOToolStripMenuItem.Size = new System.Drawing.Size(55, 20);
            this.vUELOToolStripMenuItem.Text = "VUELO";
            this.vUELOToolStripMenuItem.Click += new System.EventHandler(this.vUELOToolStripMenuItem_Click);
            // 
            // nOMINAToolStripMenuItem
            // 
            this.nOMINAToolStripMenuItem.Name = "nOMINAToolStripMenuItem";
            this.nOMINAToolStripMenuItem.Size = new System.Drawing.Size(68, 20);
            this.nOMINAToolStripMenuItem.Text = "NOMINA";
            this.nOMINAToolStripMenuItem.Click += new System.EventHandler(this.nOMINAToolStripMenuItem_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label1.Location = new System.Drawing.Point(70, 61);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(320, 55);
            this.label1.TabIndex = 6;
            this.label1.Text = "BIENVENIDO";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::GestionAeropuerto.Properties.Resources.airbus_airplane_aviation_airport_airbus_evening_light_sky_pics_766917;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1018, 533);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "AEROPUERTO";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.avionBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bBDD)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).EndInit();
            this.contextMenuStrip1.ResumeLayout(false);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private BBDD bBDD;
        private System.Windows.Forms.BindingSource avionBindingSource;
        private BBDDTableAdapters.AvionTableAdapter avionTableAdapter;
        private BBDDTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingSource bindingSource1;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem aVIONESToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem vUELOSToolStripMenuItem;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem aVIONToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem vUELOToolStripMenuItem;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ToolStripMenuItem pASAJEROToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem eMPLEADOSToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem nOMINAToolStripMenuItem;
    }
}

