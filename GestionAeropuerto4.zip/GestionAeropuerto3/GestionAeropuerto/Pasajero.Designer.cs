﻿namespace GestionAeropuerto
{
    partial class Pasajero
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label idPasajeroLabel;
            System.Windows.Forms.Label codVueloLabel;
            System.Windows.Forms.Label fechaEmbarqueLabel;
            System.Windows.Forms.Label dNILabel;
            System.Windows.Forms.Label nombreLabel;
            System.Windows.Forms.Label apellidosLabel;
            System.Windows.Forms.Label asientoLabel;
            System.Windows.Forms.Label destinoLabel;
            System.Windows.Forms.Label tipoPasajeLabel;
            System.Windows.Forms.Label pesoEquipajeLabel;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Pasajero));
            this.pasajeroBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.pasajeroBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.bBDD = new GestionAeropuerto.BBDD();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.pasajeroBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.pasajeroDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.idPasajeroTextBox = new System.Windows.Forms.TextBox();
            this.codVueloTextBox = new System.Windows.Forms.TextBox();
            this.fechaEmbarqueDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.dNITextBox = new System.Windows.Forms.TextBox();
            this.nombreTextBox = new System.Windows.Forms.TextBox();
            this.apellidosTextBox = new System.Windows.Forms.TextBox();
            this.asientoTextBox = new System.Windows.Forms.TextBox();
            this.destinoTextBox = new System.Windows.Forms.TextBox();
            this.tipoPasajeTextBox = new System.Windows.Forms.TextBox();
            this.pesoEquipajeTextBox = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.tableAdapterManager = new GestionAeropuerto.BBDDTableAdapters.TableAdapterManager();
            this.button4 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            idPasajeroLabel = new System.Windows.Forms.Label();
            codVueloLabel = new System.Windows.Forms.Label();
            fechaEmbarqueLabel = new System.Windows.Forms.Label();
            dNILabel = new System.Windows.Forms.Label();
            nombreLabel = new System.Windows.Forms.Label();
            apellidosLabel = new System.Windows.Forms.Label();
            asientoLabel = new System.Windows.Forms.Label();
            destinoLabel = new System.Windows.Forms.Label();
            tipoPasajeLabel = new System.Windows.Forms.Label();
            pesoEquipajeLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pasajeroBindingNavigator)).BeginInit();
            this.pasajeroBindingNavigator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pasajeroBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bBDD)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pasajeroDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // idPasajeroLabel
            // 
            idPasajeroLabel.AutoSize = true;
            idPasajeroLabel.Location = new System.Drawing.Point(272, 35);
            idPasajeroLabel.Name = "idPasajeroLabel";
            idPasajeroLabel.Size = new System.Drawing.Size(63, 13);
            idPasajeroLabel.TabIndex = 2;
            idPasajeroLabel.Text = "Id Pasajero:";
            // 
            // codVueloLabel
            // 
            codVueloLabel.AutoSize = true;
            codVueloLabel.Location = new System.Drawing.Point(272, 61);
            codVueloLabel.Name = "codVueloLabel";
            codVueloLabel.Size = new System.Drawing.Size(59, 13);
            codVueloLabel.TabIndex = 4;
            codVueloLabel.Text = "Cod Vuelo:";
            // 
            // fechaEmbarqueLabel
            // 
            fechaEmbarqueLabel.AutoSize = true;
            fechaEmbarqueLabel.Location = new System.Drawing.Point(272, 88);
            fechaEmbarqueLabel.Name = "fechaEmbarqueLabel";
            fechaEmbarqueLabel.Size = new System.Drawing.Size(91, 13);
            fechaEmbarqueLabel.TabIndex = 6;
            fechaEmbarqueLabel.Text = "Fecha Embarque:";
            // 
            // dNILabel
            // 
            dNILabel.AutoSize = true;
            dNILabel.Location = new System.Drawing.Point(272, 113);
            dNILabel.Name = "dNILabel";
            dNILabel.Size = new System.Drawing.Size(29, 13);
            dNILabel.TabIndex = 8;
            dNILabel.Text = "DNI:";
            // 
            // nombreLabel
            // 
            nombreLabel.AutoSize = true;
            nombreLabel.Location = new System.Drawing.Point(272, 139);
            nombreLabel.Name = "nombreLabel";
            nombreLabel.Size = new System.Drawing.Size(47, 13);
            nombreLabel.TabIndex = 10;
            nombreLabel.Text = "Nombre:";
            // 
            // apellidosLabel
            // 
            apellidosLabel.AutoSize = true;
            apellidosLabel.Location = new System.Drawing.Point(272, 165);
            apellidosLabel.Name = "apellidosLabel";
            apellidosLabel.Size = new System.Drawing.Size(52, 13);
            apellidosLabel.TabIndex = 12;
            apellidosLabel.Text = "Apellidos:";
            // 
            // asientoLabel
            // 
            asientoLabel.AutoSize = true;
            asientoLabel.Location = new System.Drawing.Point(272, 191);
            asientoLabel.Name = "asientoLabel";
            asientoLabel.Size = new System.Drawing.Size(45, 13);
            asientoLabel.TabIndex = 14;
            asientoLabel.Text = "Asiento:";
            // 
            // destinoLabel
            // 
            destinoLabel.AutoSize = true;
            destinoLabel.Location = new System.Drawing.Point(272, 217);
            destinoLabel.Name = "destinoLabel";
            destinoLabel.Size = new System.Drawing.Size(46, 13);
            destinoLabel.TabIndex = 16;
            destinoLabel.Text = "Destino:";
            // 
            // tipoPasajeLabel
            // 
            tipoPasajeLabel.AutoSize = true;
            tipoPasajeLabel.Location = new System.Drawing.Point(272, 243);
            tipoPasajeLabel.Name = "tipoPasajeLabel";
            tipoPasajeLabel.Size = new System.Drawing.Size(66, 13);
            tipoPasajeLabel.TabIndex = 18;
            tipoPasajeLabel.Text = "Tipo Pasaje:";
            // 
            // pesoEquipajeLabel
            // 
            pesoEquipajeLabel.AutoSize = true;
            pesoEquipajeLabel.Location = new System.Drawing.Point(272, 275);
            pesoEquipajeLabel.Name = "pesoEquipajeLabel";
            pesoEquipajeLabel.Size = new System.Drawing.Size(78, 13);
            pesoEquipajeLabel.TabIndex = 20;
            pesoEquipajeLabel.Text = "Peso Equipaje:";
            // 
            // pasajeroBindingNavigator
            // 
            this.pasajeroBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.pasajeroBindingNavigator.BindingSource = this.pasajeroBindingSource;
            this.pasajeroBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.pasajeroBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.pasajeroBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.pasajeroBindingNavigatorSaveItem});
            this.pasajeroBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.pasajeroBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.pasajeroBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.pasajeroBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.pasajeroBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.pasajeroBindingNavigator.Name = "pasajeroBindingNavigator";
            this.pasajeroBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.pasajeroBindingNavigator.Size = new System.Drawing.Size(1089, 25);
            this.pasajeroBindingNavigator.TabIndex = 0;
            this.pasajeroBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorAddNewItem.Text = "Agregar nuevo";
            // 
            // pasajeroBindingSource
            // 
            this.pasajeroBindingSource.DataMember = "Pasajero";
            this.pasajeroBindingSource.DataSource = this.bBDD;
            // 
            // bBDD
            // 
            this.bBDD.DataSetName = "BBDD";
            this.bBDD.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(35, 22);
            this.bindingNavigatorCountItem.Text = "of {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Número total de elementos";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorDeleteItem.Text = "Eliminar";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Mover primero";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Mover anterior";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Posición";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Posición actual";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem.Text = "Mover siguiente";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem.Text = "Mover último";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // pasajeroBindingNavigatorSaveItem
            // 
            this.pasajeroBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.pasajeroBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("pasajeroBindingNavigatorSaveItem.Image")));
            this.pasajeroBindingNavigatorSaveItem.Name = "pasajeroBindingNavigatorSaveItem";
            this.pasajeroBindingNavigatorSaveItem.Size = new System.Drawing.Size(23, 22);
            this.pasajeroBindingNavigatorSaveItem.Text = "Guardar datos";
            // 
            // pasajeroDataGridView
            // 
            this.pasajeroDataGridView.AutoGenerateColumns = false;
            this.pasajeroDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.pasajeroDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn8,
            this.dataGridViewTextBoxColumn9,
            this.dataGridViewTextBoxColumn10});
            this.pasajeroDataGridView.DataSource = this.pasajeroBindingSource;
            this.pasajeroDataGridView.Location = new System.Drawing.Point(0, 313);
            this.pasajeroDataGridView.Name = "pasajeroDataGridView";
            this.pasajeroDataGridView.Size = new System.Drawing.Size(1069, 220);
            this.pasajeroDataGridView.TabIndex = 1;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "IdPasajero";
            this.dataGridViewTextBoxColumn1.HeaderText = "IdPasajero";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "CodVuelo";
            this.dataGridViewTextBoxColumn2.HeaderText = "CodVuelo";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "FechaEmbarque";
            this.dataGridViewTextBoxColumn3.HeaderText = "FechaEmbarque";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "DNI";
            this.dataGridViewTextBoxColumn4.HeaderText = "DNI";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "Nombre";
            this.dataGridViewTextBoxColumn5.HeaderText = "Nombre";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "Apellidos";
            this.dataGridViewTextBoxColumn6.HeaderText = "Apellidos";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "Asiento";
            this.dataGridViewTextBoxColumn7.HeaderText = "Asiento";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.DataPropertyName = "Destino";
            this.dataGridViewTextBoxColumn8.HeaderText = "Destino";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.DataPropertyName = "TipoPasaje";
            this.dataGridViewTextBoxColumn9.HeaderText = "TipoPasaje";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            // 
            // dataGridViewTextBoxColumn10
            // 
            this.dataGridViewTextBoxColumn10.DataPropertyName = "PesoEquipaje";
            this.dataGridViewTextBoxColumn10.HeaderText = "PesoEquipaje";
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            // 
            // idPasajeroTextBox
            // 
            this.idPasajeroTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.pasajeroBindingSource, "IdPasajero", true));
            this.idPasajeroTextBox.Location = new System.Drawing.Point(369, 32);
            this.idPasajeroTextBox.Name = "idPasajeroTextBox";
            this.idPasajeroTextBox.Size = new System.Drawing.Size(200, 20);
            this.idPasajeroTextBox.TabIndex = 3;
            // 
            // codVueloTextBox
            // 
            this.codVueloTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.pasajeroBindingSource, "CodVuelo", true));
            this.codVueloTextBox.Location = new System.Drawing.Point(369, 58);
            this.codVueloTextBox.Name = "codVueloTextBox";
            this.codVueloTextBox.Size = new System.Drawing.Size(200, 20);
            this.codVueloTextBox.TabIndex = 5;
            // 
            // fechaEmbarqueDateTimePicker
            // 
            this.fechaEmbarqueDateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.pasajeroBindingSource, "FechaEmbarque", true));
            this.fechaEmbarqueDateTimePicker.Location = new System.Drawing.Point(369, 84);
            this.fechaEmbarqueDateTimePicker.Name = "fechaEmbarqueDateTimePicker";
            this.fechaEmbarqueDateTimePicker.Size = new System.Drawing.Size(200, 20);
            this.fechaEmbarqueDateTimePicker.TabIndex = 7;
            // 
            // dNITextBox
            // 
            this.dNITextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.pasajeroBindingSource, "DNI", true));
            this.dNITextBox.Location = new System.Drawing.Point(369, 110);
            this.dNITextBox.Name = "dNITextBox";
            this.dNITextBox.Size = new System.Drawing.Size(200, 20);
            this.dNITextBox.TabIndex = 9;
            // 
            // nombreTextBox
            // 
            this.nombreTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.pasajeroBindingSource, "Nombre", true));
            this.nombreTextBox.Location = new System.Drawing.Point(369, 136);
            this.nombreTextBox.Name = "nombreTextBox";
            this.nombreTextBox.Size = new System.Drawing.Size(200, 20);
            this.nombreTextBox.TabIndex = 11;
            // 
            // apellidosTextBox
            // 
            this.apellidosTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.pasajeroBindingSource, "Apellidos", true));
            this.apellidosTextBox.Location = new System.Drawing.Point(369, 162);
            this.apellidosTextBox.Name = "apellidosTextBox";
            this.apellidosTextBox.Size = new System.Drawing.Size(200, 20);
            this.apellidosTextBox.TabIndex = 13;
            // 
            // asientoTextBox
            // 
            this.asientoTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.pasajeroBindingSource, "Asiento", true));
            this.asientoTextBox.Location = new System.Drawing.Point(369, 188);
            this.asientoTextBox.Name = "asientoTextBox";
            this.asientoTextBox.Size = new System.Drawing.Size(200, 20);
            this.asientoTextBox.TabIndex = 15;
            // 
            // destinoTextBox
            // 
            this.destinoTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.pasajeroBindingSource, "Destino", true));
            this.destinoTextBox.Location = new System.Drawing.Point(369, 214);
            this.destinoTextBox.Name = "destinoTextBox";
            this.destinoTextBox.Size = new System.Drawing.Size(200, 20);
            this.destinoTextBox.TabIndex = 17;
            // 
            // tipoPasajeTextBox
            // 
            this.tipoPasajeTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.pasajeroBindingSource, "TipoPasaje", true));
            this.tipoPasajeTextBox.Location = new System.Drawing.Point(369, 240);
            this.tipoPasajeTextBox.Name = "tipoPasajeTextBox";
            this.tipoPasajeTextBox.Size = new System.Drawing.Size(200, 20);
            this.tipoPasajeTextBox.TabIndex = 19;
            // 
            // pesoEquipajeTextBox
            // 
            this.pesoEquipajeTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.pasajeroBindingSource, "PesoEquipaje", true));
            this.pesoEquipajeTextBox.Location = new System.Drawing.Point(369, 272);
            this.pesoEquipajeTextBox.Name = "pesoEquipajeTextBox";
            this.pesoEquipajeTextBox.Size = new System.Drawing.Size(200, 20);
            this.pesoEquipajeTextBox.TabIndex = 21;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(644, 55);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(205, 60);
            this.button1.TabIndex = 22;
            this.button1.Text = "Filtrar por Nombre";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(644, 121);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(205, 61);
            this.button2.TabIndex = 23;
            this.button2.Text = "Filtrar por Vuelo";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(644, 188);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(205, 56);
            this.button3.TabIndex = 24;
            this.button3.Text = "Filtrar por DNI";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click_1);
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.AvionTableAdapter = null;
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.Connection = null;
            this.tableAdapterManager.ControlTecnicoTableAdapter = null;
            this.tableAdapterManager.EmpleadoTableAdapter = null;
            this.tableAdapterManager.NominaTableAdapter = null;
            this.tableAdapterManager.PasajeroTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = GestionAeropuerto.BBDDTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager.VueloTableAdapter = null;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(872, 539);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(197, 41);
            this.button4.TabIndex = 25;
            this.button4.Text = "VOLVER ATRAS";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(56, 139);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(138, 25);
            this.label1.TabIndex = 26;
            this.label1.Text = "PASAJEROS";
            // 
            // Pasajero
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1089, 593);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(idPasajeroLabel);
            this.Controls.Add(this.idPasajeroTextBox);
            this.Controls.Add(codVueloLabel);
            this.Controls.Add(this.codVueloTextBox);
            this.Controls.Add(fechaEmbarqueLabel);
            this.Controls.Add(this.fechaEmbarqueDateTimePicker);
            this.Controls.Add(dNILabel);
            this.Controls.Add(this.dNITextBox);
            this.Controls.Add(nombreLabel);
            this.Controls.Add(this.nombreTextBox);
            this.Controls.Add(apellidosLabel);
            this.Controls.Add(this.apellidosTextBox);
            this.Controls.Add(asientoLabel);
            this.Controls.Add(this.asientoTextBox);
            this.Controls.Add(destinoLabel);
            this.Controls.Add(this.destinoTextBox);
            this.Controls.Add(tipoPasajeLabel);
            this.Controls.Add(this.tipoPasajeTextBox);
            this.Controls.Add(pesoEquipajeLabel);
            this.Controls.Add(this.pesoEquipajeTextBox);
            this.Controls.Add(this.pasajeroDataGridView);
            this.Controls.Add(this.pasajeroBindingNavigator);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Pasajero";
            this.Text = "Pasajero";
            ((System.ComponentModel.ISupportInitialize)(this.pasajeroBindingNavigator)).EndInit();
            this.pasajeroBindingNavigator.ResumeLayout(false);
            this.pasajeroBindingNavigator.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pasajeroBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bBDD)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pasajeroDataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private BBDD bBDD;
        private System.Windows.Forms.BindingSource pasajeroBindingSource;
        //private BBDDTableAdapters.PasajeroTableAdapter pasajeroTableAdapter;
        private BBDDTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator pasajeroBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton pasajeroBindingNavigatorSaveItem;
        private System.Windows.Forms.DataGridView pasajeroDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.TextBox idPasajeroTextBox;
        private System.Windows.Forms.TextBox codVueloTextBox;
        private System.Windows.Forms.DateTimePicker fechaEmbarqueDateTimePicker;
        private System.Windows.Forms.TextBox dNITextBox;
        private System.Windows.Forms.TextBox nombreTextBox;
        private System.Windows.Forms.TextBox apellidosTextBox;
        private System.Windows.Forms.TextBox asientoTextBox;
        private System.Windows.Forms.TextBox destinoTextBox;
        private System.Windows.Forms.TextBox tipoPasajeTextBox;
        private System.Windows.Forms.TextBox pesoEquipajeTextBox;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Label label1;
    }
}